import React, { useState } from "react";

const sampleLearners = [
  { name: "Sara", skills: ["Python", "AI", "Data Analysis"] },
  { name: "Ali", skills: ["Marketing", "Design", "Customer Support"] },
  { name: "Mona", skills: ["Cybersecurity", "Networking", "IT Support"] }
];

const employers = [
  { company: "Pima County", needs: ["Data Analysis", "AI"] },
  { company: "Vantage West", needs: ["Customer Support", "Marketing"] },
  { company: "Local IT Partner", needs: ["Cybersecurity", "Networking"] }
];

function getMatches() {
  return sampleLearners.map(learner => {
    let best = employers.map(emp => {
      const score = learner.skills.filter(skill => emp.needs.includes(skill)).length;
      return { ...emp, score };
    }).sort((a,b) => b.score - a.score)[0];

    return { learner, employer: best };
  });
}

export default function App() {
  const [matches] = useState(getMatches());

  return (
    <div className="app">
      <h1>Pima Talent Match Dashboard</h1>
      <p>AI-powered prototype matching learners with employers.</p>

      <div className="dashboard">
        {matches.map((match, index) => (
          <div key={index} className="card">
            <h2>{match.learner.name}</h2>
            <p><strong>Skills:</strong> {match.learner.skills.join(", ")}</p>
            <p><strong>Best Match:</strong> {match.employer.company}</p>
            <p><strong>AI Match Score:</strong> {match.employer.score}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
